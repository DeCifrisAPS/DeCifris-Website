#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "Operazioni2.hh"
using namespace std;

int S1[64][6] =
{{0,0,0,0,0,0},
{1,0,0,0,0,0},
{1,0,1,1,0,1},
{0,1,1,0,1,1},
{1,1,0,1,1,1},
{0,1,0,0,1,0},
{1,1,0,1,1,0},
{0,1,1,1,1,0},
{0,0,0,0,1,1},
{0,1,0,1,0,0},
{1,0,0,1,0,0},
{1,0,0,0,1,1},
{0,0,0,0,0,1},
{0,1,1,1,1,1},
{1,1,1,1,0,0},
{0,1,1,1,0,0},
{0,0,0,1,1,0},
{1,1,0,0,1,1},
{1,0,1,0,0,0},
{0,1,0,1,1,1},
{1,0,0,1,0,1},
{0,0,0,1,1,1},
{1,0,1,0,1,1},
{1,1,0,0,0,1},
{0,0,0,0,1,0},
{0,1,0,0,1,1},
{1,1,1,1,1,0},
{0,1,1,0,0,0},
{0,1,0,1,0,1},
{0,1,1,0,0,1},
{1,1,1,0,0,0},
{0,1,0,1,1,0},
{0,0,1,1,0,0},
{1,1,1,1,1,1},
{0,0,1,0,1,1},
{1,1,1,0,1,0},
{1,1,1,1,0,1},
{1,0,1,1,1,1},
{1,0,1,1,1,0},
{1,1,0,1,0,1},
{1,0,0,1,1,1},
{0,0,1,0,1,0},
{0,0,1,1,1,0},
{1,1,1,0,0,1},
{1,1,1,0,1,1},
{0,1,0,0,0,0},
{0,0,1,1,1,1},
{0,0,1,0,0,1},
{0,0,0,1,0,0},
{1,1,0,1,0,0},
{1,0,0,1,1,0},
{1,0,0,0,1,0},
{0,1,0,0,0,1},
{0,1,1,0,1,0},
{1,1,0,0,0,0},
{0,0,1,1,0,1},
{1,0,1,0,1,0},
{0,0,0,1,0,1},
{1,1,0,0,1,0},
{0,0,1,0,0,0},
{0,1,1,1,0,1},
{1,0,1,0,0,1},
{1,0,1,1,0,0},
{1,0,0,0,0,1}};

	int S2[64][6] =
{{0,0,0,0,0,0},
{1,0,0,0,0,0},
{0,0,0,0,0,1},
{1,1,0,0,1,1},
{1,0,0,0,1,1},
{1,1,0,0,0,0},
{1,1,1,1,1,1},
{1,1,1,1,1,0},
{0,0,1,0,0,1},
{0,0,1,0,0,0},
{1,1,0,1,1,1},
{1,0,0,1,0,0},
{0,1,1,1,1,1},
{1,0,1,1,0,1},
{1,1,1,1,0,0},
{0,1,1,1,0,0},
{1,1,1,0,0,0},
{1,0,1,0,0,0},
{0,1,1,0,1,1},
{0,1,1,0,0,1},
{0,0,0,1,0,0},
{1,0,0,1,1,1},
{1,1,1,0,1,0},
{0,0,1,0,1,1},
{0,1,1,1,1,0},
{1,0,1,1,1,1},
{0,0,0,0,1,0},
{1,0,0,0,0,1},
{0,1,0,1,1,1},
{0,1,0,1,0,1},
{0,1,0,1,1,0},
{0,0,0,1,1,0},
{1,0,1,1,0,0},
{1,1,0,1,0,1},
{0,1,1,0,1,0},
{0,1,0,0,0,1},
{1,0,0,1,0,1},
{0,0,1,1,1,1},
{0,0,1,1,1,0},
{1,1,0,1,1,0},
{1,1,1,0,1,1},
{0,0,0,0,1,1},
{1,1,0,0,1,0},
{0,1,1,0,0,0},
{0,0,0,1,1,1},
{0,0,1,1,0,0},
{0,1,0,0,1,1},
{0,0,1,0,1,0},
{1,1,1,1,0,1},
{0,1,0,1,0,0},
{1,0,1,0,0,1},
{0,1,0,0,1,0},
{1,0,1,0,1,1},
{1,1,0,0,0,1},
{1,0,0,0,1,0},
{1,0,1,0,1,0},
{0,0,0,1,0,1},
{0,0,1,1,0,1},
{1,0,1,1,1,0},
{1,1,0,1,0,0},
{1,0,0,1,1,0},
{0,1,1,1,0,1},
{0,1,0,0,0,0},
{1,1,1,0,0,1}};

int Traslazione[6] = {0,0,1,0,0,0};
int Traslazione2[6] = {1,0,1,0,1,0};

int Elevamento[6] = {1,2,4,8,16,32};

void controlla(int* a)
{
	int i;
	for(i = 0; i < 6; i++)
		cout << a[i];
	cout << endl;
}

void controlla24(int* a)
{
	int i;
	for(i = 0; i < 24; i++)
		cout << a[i];
	cout << endl;
}

void CreaW(int* k, int W[][6])
{
	int i, j, m;	
	//int temp[6];

	for(i = 0; i < 4; i++)
		for(j = 0; j < 6; j++)
			W[i][j] = k[j + i*6];

	int wa[4], a;
	
	for(i = 0; i < 4; i++)
		{
		wa[i] = 0;
		for(j = 0; j < 6; j++)
			wa[i] = wa[i] + k[i*6 + j] * Elevamento[j]; 
		}
	
	assegna6(W[4], S1[wa[0]]);
	assegna6(W[5], S2[wa[1]]);
	assegna6(W[6], S2[wa[2]]);
	prodmat6(W[6]);
	assegna6(W[7], S1[wa[3]]);
	sumvec6(W[7], Traslazione);

	sumvec6(W[4], W[1]);
	sumvec6(W[5], W[2]);
	sumvec6(W[6], W[3]);
	sumvec6(W[7], W[0]);

	for(m = 8; m < 88; m++)
		//cout << m << endl;
		{
		if (m % 8 == 0) 
			{
			assegna6(W[m], W[m-1]);
			RotByte(W[m]);
			
			a = 0;
			for(j = 0; j < 6; j++)
				a = a + W[m][j] * Elevamento[j];
			assegna6(W[m], S2[a]);
			sumvec6(W[m], Traslazione2);
			sumvec6(W[m], W[m-8]);
			}
		
		if (m % 8 == 4)
			{
			a = 0;
			for(j = 0; j < 6; j++)
				a = a + W[m-1][j] * Elevamento[j];

			assegna6(W[m], S2[a]);
			prodmat6(W[m]);
			sumvec6(W[m], W[m-8]);
			//controlla(W[m]);
			}
		if(m % 4 != 0)
			{
			assegna6(W[m], W[m-1]);
			sumvec6(W[m], W[m-8]);
			
			}
		}

	/*for(i = 0; i < 88; i++)
	controlla(W[i]);*/
}

void KeySchedule(int* k, int W[][6], int nround)
{
	int a, i, j;
	int asbox[4][6];

	a = (nround / 5)*20 + 8 + (nround % 5);
	assegna6(asbox[0], W[a]);
	assegna6(asbox[1], W[a+5]);
	assegna6(asbox[2], W[a+10]);
	assegna6(asbox[3], W[a+15]);
	


	for(i = 0; i < 4; i++)
		for(j = 0; j < 6; j++)
			k[i*6 + j] = asbox[i][j];
}	


void Round(int* iv, int nround)
{
	int asbox[4][6];
	int i, j;
	int wa[4];
	
	for(i = 0; i < 4; i++)
		{
		wa[i] = 0;
		for(j = 0; j < 6; j++)
			wa[i] = wa[i] + iv[i*6 + j] * Elevamento[j];
		}

	assegna6(asbox[0], S1[wa[0]]);
	assegna6(asbox[1], S2[wa[1]]);
	assegna6(asbox[2], S2[wa[2]]);
	prodmat6(asbox[2]);
	assegna6(asbox[3], S1[wa[3]]);
	sumvec6(asbox[3], Traslazione);

	for(i = 0; i < 4; i++)
		for(j = 0; j < 6; j++)
			iv[i*6 + j] = asbox[i][j];
	prodmat24(iv);
}

void Encode(int* iv, int W[][6])
{
	int k[24];
	int nround;

	KeySchedule(k, W, 0);
	sumvec24(iv, k);
	for(nround = 0; nround < 15; nround++)
	{
		Round(iv, nround);
		KeySchedule(k, W, nround+1);
		sumvec24(iv, k);
	}
}

void Stampa(int* iv)
{
	FILE* stampa;
	stampa = fopen("outputbunny.txt", "a");
	fprintf(stampa, "w = %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n", iv[0], iv[1], iv[2], iv[3], iv[4], iv[5], iv[6], iv[7], iv[8], iv[9], iv[10], iv[11], iv[12], iv[13], iv[14], iv[15], iv[16], iv[17], iv[18], iv[19], iv[20], iv[21], iv[22], iv[23], iv[24]); 
	fclose(stampa);
}


int main()
{
	FILE* dati;
	dati = fopen("datibunny.txt", "r");
	
	int i;
	int k[24]; /* Assegno la chiave*/
	int iv[24]; /* Assegno il messaggio */
	int W[88][6];
	
	
	fscanf(dati, "k = %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n", &k[0], &k[1], &k[2], &k[3], &k[4], &k[5], &k[6], &k[7], &k[8], &k[9], &k[10], &k[11], &k[12], &k[13], &k[14], &k[15], &k[16], &k[17], &k[18], &k[19], &k[20], &k[21], &k[22], &k[23], &k[24]);
	fscanf(dati, "iv = %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d\n", &iv[0], &iv[1], &iv[2], &iv[3], &iv[4], &iv[5], &iv[6], &iv[7], &iv[8], &iv[9], &iv[10], &iv[11], &iv[12], &iv[13], &iv[14], &iv[15], &iv[16], &iv[17], &iv[18], &iv[19], &iv[20], &iv[21], &iv[22], &iv[23], &iv[24]); 

	fclose(dati);

	CreaW(k, W);
	Encode(iv, W);

	Stampa(iv);
	controlla24(iv);
	//scanf("%d", i);	
	return 0;
}

