#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "OperazioniD2.cpp"
using namespace std;


void assegna6(int* a, int* b);


void assegna24(int* a, int* b);


void sumvec6(int* a, int* b);


void sumvec24(int* a, int* b);


void prodmat6(int* a);


void prodmatD6(int* a);

	
void prodmat24(int* a);


void RotByte(int* a);
